# v1.2.0
## 04/27/2020

1. [](#improved)
    * Use `info` instead of `warning` when logging [#5](https://github.com/getgrav/grav-plugin-precache/pull/5)
    * Set current page in Grav object [#8](https://github.com/getgrav/grav-plugin-precache/pull/8)

# v1.1.3
## 03/24/2017

1. [](#bugfix)
    * Force rebuild and re-release 

# v1.1.2
## 05/03/2016

1. [](#bugfix)
    * Fixed bad label resulting in double "Plugin Status" labels 

# v1.1.1
## 01/15/2016

1. [](#new)
    * Updated blueprints and README.md

# v1.1.0
## 01/15/2016

1. [](#new)
    * Added an option to turn off warning logs
    * Added a new CLI command

# v1.0.1
## 12/17/2014

1. [](#new)
    * ChangeLog started...
